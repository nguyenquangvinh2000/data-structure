#include<iostream>
using namespace std;
class stack{
    private:
        struct node{
            int item;
            node *next;
        };
        int size;
        node *head;
    public:
        stack(){
            size=0;
        }
        bool isEmpty(){
            if(size==0){
                return true;
            }
            else {
                return false;
            }
        }
        void push(int newItem){
            node *push;
            push = new node;
            push->item=newItem;
            if(head==NULL){
                push->next = NULL;
            }
            else {
                push->next=head;

            }
            head = push;
            size++;
            

        }
        void pop(){
            if(head==0){
                cout<<"empty";
            }
            else {
                node *del=head;
                head=head->next;
                del->next=NULL;
                delete del;
            }
            size--;
        }
        int getSize(){
            return size;
        }
        void print(){
            node *p;
            p=head;
            for(int i=0;i<=size;i++){
                cout<<p->item<<endl;
                p=p->next;
            }
        }
};
int main(){
    stack s;
    s.push(1);
    s.push(2);
    s.push(3);
    s.pop();
    s.print();
}