#include<iostream>
using namespace std;

int main(){
    int arr[100];
    int n;
    cout<<"nhập n:";
    cin>>n;
    for(int i=0;i<n;i++){
        arr[i]=0;
    }
    for(int i=0;i<n;i++)
    {
        cout<<arr[i];
    }
    cout<<endl;
    for(int i=n-1;i>=0;i--){
        if(arr[i]==0)
        {
            arr[i]=1;
            for(int j=i+1;j<n;j++){
                arr[j]=0;
            }
            for(int j=0;j<n;j++)
            {
                cout<<arr[j];
            }
            cout<<endl;
            i=n;
        }
    }
    return 0;
}