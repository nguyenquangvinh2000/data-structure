#include<iostream>
using namespace std;
class LinkedList {
    private:
        struct node{
            int item;
            node *next;
        };
        int size;
        node *head;
    public:
        LinkedList(){
            size = 0;
            head = NULL;
        }
        bool isEmpty(){
            if(size==0)
                return true;
            else
                return false;
            
        }
        void push_front(int newItem){
            node *p = new node();
            p->item = newItem;
            p->next=NULL;
            head = p;

        }
        void deleleNode(){
            if(!isEmpty()){
                node *d=head;
                head=head->next;

                d->next=NULL;
                delete d;
                size--;
            }
        }
};

int main(){
    LinkedList l;
    node *p;
    p=item;
    for(int i=0;i<=size)

}