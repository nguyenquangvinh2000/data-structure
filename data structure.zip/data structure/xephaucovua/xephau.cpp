#include <iostream>
using namespace std;
char a[100][100];
int N;
void InBanCo()
{
  for(int i = 0; i<N; i++)
  {
    for(int j = 0; j<N; j++)
      cout<<a[i][j]<<" ";
    cout<<endl;
  }
  cout<<"***********************\n";
}
bool XepDuocHau(int h, int c)
{
  for(int k = 1; k<c; k++)
    if (a[h-1][k-1] == 'H')
      return false;
  for(int x = h-1, y = c-1; x>=1 && y>=1; x--, y--)
  {
    if (a[x-1][y-1] == 'H')
      return false;
  }
  for(int x= h+1, y = c-1; x<=N && y>= 1; x++, y--)
  {
    if (a[x-1][y-1] == 'H')
      return false;
  }
  return true;
}
void XepHau(int c, int N)
{
  if (c>N)
  {
    InBanCo();
  }
  else
  {
    for(int h = 1; h<=N; h++)
    {
      if (XepDuocHau(h, c))
      {
        a[h-1][c-1] = 'H';
        XepHau(c+1, N);
        a[h-1][c-1] = '-';
      }
    }
  }
}
int main() 
{
    cout<<"nhap n:";
    cin>>N;
  //Khoi tao ban co, dau - chua hau
  for(int i = 0; i<N; i++)
    for(int j = 0; j<N; j++)
      a[i][j] = '-';

  XepHau(1, N); 
}
