#include<iostream>
using namespace std;

struct treenode{
    int data;
    treenode *left;
    treenode *right;
};
void addItem(treenode *&g,int item){
    if(g==NULL){
        treenode *newData = new treenode;
        newData->data = item;
        newData->left = NULL;
        newData->right = NULL;
        
    }
    else{
        if(g->data > item){
            addItem(g->left, item);
        }
        else{
            addItem(g->right, item);
        }
    }
}
void printTree(treenode * g){
    if(g!=NULL){
        printTree(g->left);
        cout<<g->data<<" ";
        printTree(g->right);
    }
}
int main(){
    int n, item;
    cout<<"nhập n:";
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>item;
        addItem(g,item);
        
    }
    printTree(g);
}