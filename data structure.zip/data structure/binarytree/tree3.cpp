#include<iostream>
using namespace std;


struct treenode{
    int data;
    treenode *left;
    treenode *right;
};
typedef treenode *node;
typedef node *tree;

void khoitaocay(tree *t)
{
    t = NULL;
}
void addItem(tree *t,int x)
{
    if( t== NULL){
        treenode *p = new treenode;
        p -> data = x; //thêm dữ liệu x vào data
        p->left = NULL; 
        p->right = NULL;
        t=p;

    }
    else
    {
        if(t->data > x){
            addItem(t->left,x);
        }
        else if(t->)
    }
}
int main(){

}
