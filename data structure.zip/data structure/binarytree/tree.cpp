#include<iostream>
using namespace std;

struct TreeNode {
    int item;
    TreeNode *left;
    TreeNode *right;
};
void addItem(struct TreeNode *&treeNode, struct TreeNode *newNode){
    if(treeNode==NULL){
        treeNode=newNode;
    }
    else if(newNode->item < treeNode->item){
        addItem(treeNode->left, newNode);
    }
    else
    {
        addItem(treeNode->right, newNode);
    }
    
}
void search(TreeNode, key){
    if(TreeNode == NULL)[
        return none;
    ]
}
int main(){

}
